from setuptools import setup, find_packages

setup(
    name='Network_Pruner',
    version='0.6',
    author='Chenqing Lin',
    author_email='24020040061@pop.zjgsu.edu.cn',
    packages = ["Network_Pruner"],
    install_requires=[

    ]
)