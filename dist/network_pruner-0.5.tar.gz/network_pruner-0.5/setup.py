from setuptools import setup, find_packages

setup(
    name='Network_Pruner',
    version='0.5',
    author='Chenqing Lin',
    author_email='24020040061@pop.zjgsu.edu.cn',
    install_requires=[

    ]
)